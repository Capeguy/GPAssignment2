// Module: Games Programming
// Assignment 2: GRPG
// Student Name: Jeremy Lim
// Student Number: S10122326F

#ifndef GLOBALS_H
#define GLOBALS_H

#include <fstream>
#include <iostream>
#include <string>


#endif